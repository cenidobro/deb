import { NextRequest, NextResponse } from 'next/server'
import { readFile } from 'fs/promises'
import { join } from 'path'

export async function GET(request: NextRequest) {
  try {
    const filePath = join(process.cwd(), 'tiktok-configs-shop-v1.0-final.tar.gz')
    
    // Read the file
    const fileBuffer = await readFile(filePath)
    
    // Return the file as a downloadable response
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': 'application/gzip',
        'Content-Disposition': 'attachment; filename="tiktok-configs-shop-v1.0-final.tar.gz"',
        'Content-Length': fileBuffer.length.toString(),
      },
    })
  } catch (error) {
    console.error('Error serving archive:', error)
    return NextResponse.json(
      { error: 'Archive not found or could not be served' },
      { status: 404 }
    )
  }
}