'use client';

import { useEffect, useState, useRef } from 'react';

export default function Home() {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('login');
  const [authMessage, setAuthMessage] = useState<{text: string, type: string} | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const products = {
    1: {
      title: "BASIC CONFIG",
      price: "0.001 BTC",
      btcAddress: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    },
    2: {
      title: "ADVANCED CONFIG", 
      price: "0.00125 BTC",
      btcAddress: "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"
    },
    3: {
      title: "PREMIUM CONFIG",
      price: "0.00175 BTC", 
      btcAddress: "bc1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3qccfmv3"
    },
    4: {
      title: "ENTERPRISE CONFIG",
      price: "0.0025 BTC",
      btcAddress: "bc1pw508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7k7grplx"
    },
    5: {
      title: "ULTIMATE CONFIG",
      price: "0.005 BTC",
      btcAddress: "bc1zw508d6qejxtdg4y5r3zarvaryvqyzf3du"
    },
    6: {
      title: "TIKTOK IPA BASIC",
      price: "0.0005 BTC",
      btcAddress: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    },
    7: {
      title: "TIKTOK IPA ADVANCED",
      price: "0.001 BTC",
      btcAddress: "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"
    },
    8: {
      title: "TIKTOK IPA PREMIUM",
      price: "0.00125 BTC",
      btcAddress: "bc1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3qccfmv3"
    },
    9: {
      title: "TIKTOK IPA ENTERPRISE",
      price: "0.00175 BTC",
      btcAddress: "bc1pw508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7k7grplx"
    },
    10: {
      title: "TIKTOK IPA ULTIMATE",
      price: "0.0025 BTC",
      btcAddress: "bc1zw508d6qejxtdg4y5r3zarvaryvqyzf3du"
    },
    11: {
      title: "DYLIB FILES BASIC",
      price: "0.001 BTC",
      btcAddress: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh"
    },
    12: {
      title: "DYLIB FILES ADVANCED",
      price: "0.0015 BTC",
      btcAddress: "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"
    },
    13: {
      title: "DYLIB FILES PREMIUM",
      price: "0.002 BTC",
      btcAddress: "bc1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3qccfmv3"
    },
    14: {
      title: "DYLIB FILES ENTERPRISE",
      price: "0.003 BTC",
      btcAddress: "bc1pw508d6qejxtdg4y5r3zarvary0c5xw7kw508d6qejxtdg4y5r3zarvary0c5xw7k7grplx"
    },
    15: {
      title: "DYLIB FILES ULTIMATE",
      price: "0.005 BTC",
      btcAddress: "bc1zw508d6qejxtdg4y5r3zarvaryvqyzf3du"
    }
  };

  const mockUsers = [
    { id: 1, username: 'admin', email: 'admin@example.com', last_ip: '192.168.1.100', country: 'RU', browser: 'Chrome', device: 'Desktop', is_active: true, is_admin: true, last_login: new Date() },
    { id: 2, username: 'testuser', email: 'test@example.com', last_ip: '203.0.113.45', country: 'US', browser: 'Firefox', device: 'Mobile', is_active: true, is_admin: false, last_login: new Date() },
  ];

  // Matrix rain effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    function setCanvasSize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const fontSize = 16;
    let columns = Math.floor(canvas.width / fontSize);
    const drops = [];

    for (let i = 0; i < columns; i++) {
      drops[i] = 1;
    }

    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      ctx.fillStyle = '#00ff41';
      ctx.font = fontSize + 'px monospace';
      
      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.99) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }
    
    const intervalId = setInterval(draw, 33);

    return () => {
      window.removeEventListener('resize', setCanvasSize);
      clearInterval(intervalId);
    };
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const dropdown = document.querySelector('.nav-item.dropdown');
      if (dropdown && !dropdown.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Typing effect
  useEffect(() => {
    if (!currentUser) return;
    
    const text = "TikTok_Configs.shop";
    const element = document.querySelector('.typing-text');
    if (!element) return;
    
    let i = 0;
    element.textContent = '';
    
    const typeWriter = () => {
      if (i < text.length) {
        element.textContent += text.charAt(i);
        i++;
        setTimeout(typeWriter, 100);
      }
    };
    
    typeWriter();
  }, [currentUser]);

  const mockLogin = async (username: string, password: string) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (username === 'admin' && password === 'admin123') {
          resolve({ authenticated: true, user: { username: 'admin', is_admin: true } });
        } else if (username === 'testuser' && password === 'testpass123') {
          resolve({ authenticated: true, user: { username: 'testuser', is_admin: false } });
        } else {
          reject({ error: 'Неверный логин или пароль' });
        }
      }, 500);
    });
  };

  const mockRegister = async (username: string, email: string, password: string) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (username === 'newuser') {
          reject({ error: 'Пользователь с таким логином уже существует' });
        } else {
          resolve({ message: 'Регистрация успешна!' });
        }
      }, 500);
    });
  };

  const showMessage = (message: string, type: string = 'error') => {
    setAuthMessage({ text: message, type });
    setTimeout(() => setAuthMessage(null), 3000);
  };

  const handleLogin = async () => {
    const username = (document.getElementById('login-username') as HTMLInputElement)?.value.trim();
    const password = (document.getElementById('login-password') as HTMLInputElement)?.value;
    
    if (!username || !password) {
      showMessage('Логин и пароль обязательны');
      return;
    }
    
    try {
      const response: any = await mockLogin(username, password);
      setCurrentUser(response.user);
      if (response.user.is_admin) {
        setShowAdminPanel(true);
      }
    } catch (error: any) {
      showMessage(error.error || 'Неизвестная ошибка входа');
    }
  };

  const handleRegister = async () => {
    const username = (document.getElementById('register-username') as HTMLInputElement)?.value.trim();
    const email = (document.getElementById('register-email') as HTMLInputElement)?.value.trim();
    const password = (document.getElementById('register-password') as HTMLInputElement)?.value;
    
    if (!username || !email || !password) {
      showMessage('Все поля обязательны для заполнения');
      return;
    }
    
    try {
      const response: any = await mockRegister(username, email, password);
      showMessage(response.message, 'success');
      setTimeout(() => {
        setActiveTab('login');
        (document.getElementById('login-username') as HTMLInputElement)!.value = username;
      }, 2000);
    } catch (error: any) {
      showMessage(error.error);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setShowAdminPanel(false);
  };

  const openModal = (productId: number) => {
    const product = products[productId as keyof typeof products];
    setSelectedProduct(product);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedProduct(null);
  };

  const copyAddress = () => {
    if (!selectedProduct) return;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(selectedProduct.btcAddress).then(() => {
        const copyBtn = document.querySelector('.copy-btn');
        if (copyBtn) {
          const originalText = copyBtn.textContent;
          copyBtn.textContent = 'COPIED!';
          (copyBtn as HTMLElement).style.background = '#2ecc71';
          
          setTimeout(() => {
            copyBtn.textContent = originalText;
            (copyBtn as HTMLElement).style.background = '';
          }, 2000);
        }
      });
    }
  };

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDropdownItemClick = (itemText: string) => {
    setShowDropdown(false);
    
    if (itemText === 'configs') {
      scrollToSection('products');
    } else if (itemText === 'IPA') {
      scrollToSection('ipa');
    } else if (itemText === 'File .dylib') {
      scrollToSection('dylib');
    }
  };

  const handleDownload = () => {
    // Создаем ссылку для скачивания архива
    const link = document.createElement('a');
    link.href = '/api/download-archive';
    link.download = 'tiktok-configs-shop-v1.0-final.tar.gz';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Показываем уведомление о начале загрузки
    showMessage('Начинается загрузка архива сайта...', 'success');
  };

  if (!currentUser) {
    return (
      <>
        {/* Matrix Background */}
        <div id="matrix-bg">
          <canvas ref={canvasRef} id="matrix-canvas" />
        </div>
        
        <div className="auth-panel">
          <div className="auth-container">
            <div className="auth-header">
              <h1 className="auth-title">Access Panel</h1>
              <p className="auth-subtitle">Premium Access Panel</p>
            </div>
            
            <div className="auth-tabs">
              <button 
                className={`auth-tab ${activeTab === 'login' ? 'active' : ''}`} 
                onClick={() => setActiveTab('login')}
              >
                Login
              </button>
              <button 
                className={`auth-tab ${activeTab === 'register' ? 'active' : ''}`} 
                onClick={() => setActiveTab('register')}
              >
                Register
              </button>
            </div>
            
            {activeTab === 'login' && (
              <div className="auth-form active">
                <div className="form-group">
                  <label htmlFor="login-username">Username</label>
                  <input type="text" id="login-username" placeholder="Enter username" required />
                </div>
                <div className="form-group">
                  <label htmlFor="login-password">Password</label>
                  <input type="password" id="login-password" placeholder="Enter password" required />
                </div>
                <button className="auth-btn" onClick={handleLogin}>Login</button>
              </div>
            )}
            
            {activeTab === 'register' && (
              <div className="auth-form active">
                <div className="form-group">
                  <label htmlFor="register-username">Username</label>
                  <input type="text" id="register-username" placeholder="Enter username" required />
                </div>
                <div className="form-group">
                  <label htmlFor="register-email">Email</label>
                  <input type="email" id="register-email" placeholder="Enter email" required />
                </div>
                <div className="form-group">
                  <label htmlFor="register-password">Password</label>
                  <input type="password" id="register-password" placeholder="Enter password" required />
                </div>
                <button className="auth-btn" onClick={handleRegister}>Register</button>
              </div>
            )}
            
            {authMessage && (
              <div className={`auth-message ${authMessage.type}`}>
                {authMessage.text}
              </div>
            )}
          </div>
        </div>

        <style jsx global>{`
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }

          body {
            font-family: 'Fira Code', monospace;
            background: #000000;
            color: #ffffff;
            overflow-x: hidden;
            line-height: 1.6;
          }

          .auth-panel {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(2px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
          }

          .auth-panel::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"><animate attributeName="opacity" values="0;1;0" dur="3s" repeatCount="indefinite"/></circle><circle cx="80" cy="80" r="3" fill="rgba(255,255,255,0.1)"><animate attributeName="opacity" values="0;1;0" dur="4s" repeatCount="indefinite"/></circle><circle cx="40" cy="70" r="1" fill="rgba(255,255,255,0.1)"><animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite"/></circle></svg>');
            animation: float 20s ease-in-out infinite;
          }

          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
          }

          .auth-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            width: 400px;
            max-width: 90vw;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
          }

          .auth-header {
            text-align: center;
            margin-bottom: 30px;
          }

          .auth-title {
            font-family: 'Orbitron', monospace;
            font-size: 2.5rem;
            font-weight: 900;
            color: #ffffff;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
          }

          .auth-subtitle {
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 300;
          }

          .auth-tabs {
            display: flex;
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.1);
          }

          .auth-tab {
            flex: 1;
            padding: 12px 20px;
            background: transparent;
            border: none;
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Fira Code', monospace;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
          }

          .auth-tab.active {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
          }

          .auth-tab:hover {
            background: rgba(255, 255, 255, 0.15);
            color: #ffffff;
          }

          .auth-form {
            display: none;
          }

          .auth-form.active {
            display: block;
          }

          .form-group {
            margin-bottom: 20px;
          }

          .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 500;
          }

          .form-group input {
            width: 100%;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            color: #ffffff;
            font-family: 'Fira Code', monospace;
            font-size: 0.9rem;
            transition: all 0.3s ease;
          }

          .form-group input:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.5);
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
          }

          .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }

          .auth-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-family: 'Orbitron', monospace;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
          }

          .auth-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.4);
          }

          .auth-btn:active {
            transform: translateY(0);
          }

          .auth-message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            font-size: 0.9rem;
          }

          .auth-message.success {
            background: rgba(46, 204, 113, 0.2);
            border: 1px solid rgba(46, 204, 113, 0.5);
            color: #2ecc71;
          }

          .auth-message.error {
            background: rgba(231, 76, 60, 0.2);
            border: 1px solid rgba(231, 76, 60, 0.5);
            color: #e74c3c;
          }
        `}</style>
      </>
    );
  }

  return (
    <>
      {/* Matrix Background */}
      <div id="matrix-bg">
        <canvas ref={canvasRef} id="matrix-canvas" />
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <header className="header">
          <div className="container">
            <h1 className="logo" id="site-logo" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} style={{ cursor: 'pointer' }}>
              <span className="typing-text">TikTok_Configs.shop</span>
              <span className="cursor">_</span>
            </h1>
            <nav className="nav">
              <div className="nav-item dropdown">
                <a 
                  href="#" 
                  className="nav-link dropdown-toggle"
                  onClick={(e) => {
                    e.preventDefault();
                    setShowDropdown(!showDropdown);
                  }}
                >
                  [PRODUCTS]
                </a>
                <div className={`dropdown-menu ${showDropdown ? 'show' : ''}`}>
                  <a 
                    href="#products" 
                    className="dropdown-item"
                    onClick={(e) => {
                      e.preventDefault();
                      handleDropdownItemClick('configs');
                    }}
                  >
                    configs
                  </a>
                  <a 
                    href="#ipa" 
                    className="dropdown-item"
                    onClick={(e) => {
                      e.preventDefault();
                      handleDropdownItemClick('IPA');
                    }}
                  >
                    IPA
                  </a>
                  <a 
                    href="#dylib" 
                    className="dropdown-item"
                    onClick={(e) => {
                      e.preventDefault();
                      handleDropdownItemClick('File .dylib');
                    }}
                  >
                    File .dylib
                  </a>
                </div>
              </div>
              <a href="#security" className="nav-link">[SECURITY]</a>
              <a href="#contact" className="nav-link">[CONTACT]</a>
              {showAdminPanel && (
                <>
                  <a href="#admin" className="nav-link admin-link">[ADMIN]</a>
                  <button className="nav-link download-btn" onClick={handleDownload}>[DOWNLOAD]</button>
                </>
              )}
              <button className="nav-link logout-btn" onClick={handleLogout}>[LOGOUT]</button>
            </nav>
          </div>
        </header>

        {/* Main Content */}
        <main className="main">
          <div className="container">
            {/* Hero Section */}
            <section className="hero">
              <h2 className="hero-title">
                <span className="glitch" data-text="PREMIUM TIKTOK CONFIGURATIONS">PREMIUM TIKTOK CONFIGURATIONS</span>
              </h2>
              <p className="hero-subtitle">Exclusive configuration files for maximum efficiency</p>
              <div className="terminal-window">
                <div className="terminal-header">
                  <span className="terminal-button red"></span>
                  <span className="terminal-button yellow"></span>
                  <span className="terminal-button green"></span>
                  <span className="terminal-title">root@darkweb:~$</span>
                </div>
                <div className="terminal-body">
                  <p><span className="prompt">$</span> ls -la /configs/tiktok/</p>
                  <p>total 5</p>
                  <p>-rw-r--r-- 1 root root 2048 Jan 15 12:00 basic_config.json</p>
                  <p>-rw-r--r-- 1 root root 4096 Jan 15 12:00 advanced_config.json</p>
                  <p>-rw-r--r-- 1 root root 8192 Jan 15 12:00 premium_config.json</p>
                  <p>-rw-r--r-- 1 root root 16384 Jan 15 12:00 enterprise_config.json</p>
                  <p>-rw-r--r-- 1 root root 32768 Jan 15 12:00 ultimate_config.json</p>
                </div>
              </div>
            </section>

            {/* Products Section */}
            <section id="products" className="products">
              <h3 className="section-title">
                <span className="bracket">[</span>AVAILABLE CONFIGURATIONS<span className="bracket">]</span>
              </h3>
              
              <div className="products-grid">
                {/* Product 1 */}
                <div className="product-card" data-product="1">
                  <div className="product-header">
                    <h4 className="product-title">BASIC CONFIG</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Basic algorithm settings</li>
                      <li>✓ Standard coverage parameters</li>
                      <li>✓ Basic content filters</li>
                      <li>✓ 24/7 support</li>
                    </ul>
                    <div className="product-price">0.001 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(1)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* Product 2 */}
                <div className="product-card" data-product="2">
                  <div className="product-header">
                    <h4 className="product-title">ADVANCED CONFIG</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Advanced algorithms</li>
                      <li>✓ Trend optimization</li>
                      <li>✓ Advanced analytics</li>
                      <li>✓ Priority support</li>
                    </ul>
                    <div className="product-price">0.00125 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(2)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* Product 3 */}
                <div className="product-card featured" data-product="3">
                  <div className="product-header">
                    <h4 className="product-title">PREMIUM CONFIG</h4>
                    <span className="product-status featured">POPULAR</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Premium algorithms</li>
                      <li>✓ Maximum reach</li>
                      <li>✓ AI-optimization</li>
                      <li>✓ Exclusive features</li>
                      <li>✓ VIP support</li>
                    </ul>
                    <div className="product-price">0.00175 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(3)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* Product 4 */}
                <div className="product-card" data-product="4">
                  <div className="product-header">
                    <h4 className="product-title">ENTERPRISE CONFIG</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Corporate solutions</li>
                      <li>✓ Multi-account support</li>
                      <li>✓ Enhanced security</li>
                      <li>✓ Business customization</li>
                      <li>✓ Personal manager</li>
                    </ul>
                    <div className="product-price">0.0025 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(4)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* Product 5 */}
                <div className="product-card ultimate" data-product="5">
                  <div className="product-header">
                    <h4 className="product-title">ULTIMATE CONFIG</h4>
                    <span className="product-status ultimate">EXCLUSIVE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Maximum capabilities</li>
                      <li>✓ Exclusive algorithms</li>
                      <li>✓ Full customization</li>
                      <li>✓ Private APIs</li>
                      <li>✓ Unlimited support</li>
                      <li>✓ Result guarantee</li>
                    </ul>
                    <div className="product-price">0.005 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(5)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>
              </div>
            </section>

            {/* TikTok IPA Section */}
            <section id="ipa" className="products">
              <h3 className="section-title">
                <span className="bracket">[</span>TIKTOK IPA<span className="bracket">]</span>
              </h3>
              
              <div className="products-grid">
                {/* IPA Product 1 */}
                <div className="product-card" data-product="6">
                  <div className="product-header">
                    <h4 className="product-title">TIKTOK IPA BASIC</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Basic TikTok modification</li>
                      <li>✓ Ads removed</li>
                      <li>✓ Video download</li>
                      <li>✓ Advanced settings</li>
                    </ul>
                    <div className="product-price">0.0005 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(6)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* IPA Product 2 */}
                <div className="product-card" data-product="7">
                  <div className="product-header">
                    <h4 className="product-title">TIKTOK IPA ADVANCED</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Advanced features</li>
                      <li>✓ Anonymous browsing</li>
                      <li>✓ Bulk download</li>
                      <li>✓ Custom filters</li>
                    </ul>
                    <div className="product-price">0.001 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(7)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* IPA Product 3 */}
                <div className="product-card featured" data-product="8">
                  <div className="product-header">
                    <h4 className="product-title">TIKTOK IPA PREMIUM</h4>
                    <span className="product-status featured">POPULAR</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Premium capabilities</li>
                      <li>✓ AI recommendations</li>
                      <li>✓ Unlimited likes</li>
                      <li>✓ Private functions</li>
                      <li>✓ VIP status</li>
                    </ul>
                    <div className="product-price">0.00125 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(8)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* IPA Product 4 */}
                <div className="product-card" data-product="9">
                  <div className="product-header">
                    <h4 className="product-title">TIKTOK IPA ENTERPRISE</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Corporate solutions</li>
                      <li>✓ Multi-account management</li>
                      <li>✓ Advanced analytics</li>
                      <li>✓ Action automation</li>
                      <li>✓ Personal support</li>
                    </ul>
                    <div className="product-price">0.00175 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(9)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* IPA Product 5 */}
                <div className="product-card ultimate" data-product="10">
                  <div className="product-header">
                    <h4 className="product-title">TIKTOK IPA ULTIMATE</h4>
                    <span className="product-status ultimate">EXCLUSIVE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Maximum capabilities</li>
                      <li>✓ Exclusive functions</li>
                      <li>✓ Full customization</li>
                      <li>✓ Private APIs</li>
                      <li>✓ Unlimited support</li>
                      <li>✓ Result guarantee</li>
                    </ul>
                    <div className="product-price">0.0025 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(10)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>
              </div>
            </section>

            {/* TikTok DYLIB Section */}
            <section id="dylib" className="products">
              <h3 className="section-title">
                <span className="bracket">[</span>DYLIB FILES<span className="bracket">]</span>
              </h3>
              
              <div className="products-grid">
                {/* DYLIB Product 1 */}
                <div className="product-card" data-product="11">
                  <div className="product-header">
                    <h4 className="product-title">DYLIB FILES BASIC</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Basic library</li>
                      <li>✓ Standard functions</li>
                      <li>✓ Core functionalities</li>
                      <li>✓ 24/7 support</li>
                    </ul>
                    <div className="product-price">0.001 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(11)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* DYLIB Product 2 */}
                <div className="product-card" data-product="12">
                  <div className="product-header">
                    <h4 className="product-title">DYLIB FILES ADVANCED</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Extended functions</li>
                      <li>✓ Performance optimization</li>
                      <li>✓ Advanced capabilities</li>
                      <li>✓ Priority support</li>
                    </ul>
                    <div className="product-price">0.0015 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(12)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* DYLIB Product 3 */}
                <div className="product-card featured" data-product="13">
                  <div className="product-header">
                    <h4 className="product-title">DYLIB FILES PREMIUM</h4>
                    <span className="product-status featured">POPULAR</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Premium functions</li>
                      <li>✓ Maximum performance</li>
                      <li>✓ AI-optimization</li>
                      <li>✓ Exclusive features</li>
                      <li>✓ VIP support</li>
                    </ul>
                    <div className="product-price">0.002 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(13)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* DYLIB Product 4 */}
                <div className="product-card" data-product="14">
                  <div className="product-header">
                    <h4 className="product-title">DYLIB FILES ENTERPRISE</h4>
                    <span className="product-status">AVAILABLE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Corporate solutions</li>
                      <li>✓ Multi-account management</li>
                      <li>✓ Enhanced security</li>
                      <li>✓ Project customization</li>
                      <li>✓ Personal manager</li>
                    </ul>
                    <div className="product-price">0.003 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(14)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>

                {/* DYLIB Product 5 */}
                <div className="product-card ultimate" data-product="15">
                  <div className="product-header">
                    <h4 className="product-title">DYLIB FILES ULTIMATE</h4>
                    <span className="product-status ultimate">EXCLUSIVE</span>
                  </div>
                  <div className="product-body">
                    <ul className="product-features">
                      <li>✓ Maximum capabilities</li>
                      <li>✓ Exclusive functions</li>
                      <li>✓ Full customization</li>
                      <li>✓ Private APIs</li>
                      <li>✓ Unlimited support</li>
                      <li>✓ Result guarantee</li>
                    </ul>
                    <div className="product-price">0.005 BTC</div>
                  </div>
                  <button className="buy-btn" onClick={() => openModal(15)}>
                    <span className="btn-text">[BUY]</span>
                    <span className="btn-glow"></span>
                  </button>
                </div>
              </div>
            </section>

            {/* Admin Panel Section */}
            {showAdminPanel && (
              <section id="admin" className="admin-panel">
                <h3 className="section-title">
                  <span className="bracket">[</span>ADMIN PANEL<span className="bracket">]</span>
                </h3>
                
                <div className="admin-content">
                  <div className="users-table-container">
                    <table className="users-table">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Логин</th>
                          <th>Email</th>
                          <th>IP</th>
                          <th>Страна</th>
                          <th>Браузер</th>
                          <th>Устройство</th>
                          <th>Статус</th>
                          <th>Админ</th>
                          <th>Последний вход</th>
                          <th>Действия</th>
                        </tr>
                      </thead>
                      <tbody id="users-table-body">
                        {mockUsers.map(user => (
                          <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.username}</td>
                            <td>{user.email}</td>
                            <td>{user.last_ip || 'N/A'}</td>
                            <td>{user.country || 'N/A'}</td>
                            <td>{user.browser || 'N/A'}</td>
                            <td>{user.device || 'N/A'}</td>
                            <td>
                              <span className={`status-badge ${user.is_active ? 'active' : 'inactive'}`}>
                                {user.is_active ? 'Активен' : 'Неактивен'}
                              </span>
                            </td>
                            <td>
                              {user.is_admin ? <span className="admin-badge">Админ</span> : ''}
                            </td>
                            <td>{user.last_login ? new Date(user.last_login).toLocaleDateString('ru-RU') + ' ' + new Date(user.last_login).toLocaleTimeString('ru-RU') : 'Никогда'}</td>
                            <td>
                              <div className="admin-actions">
                                {user.id !== currentUser?.id ? (
                                  <>
                                    <button 
                                      className="admin-btn toggle" 
                                      onClick={() => alert('Функция недоступна в демо-режиме')}
                                    >
                                      {user.is_active ? 'Деактивировать' : 'Активировать'}
                                    </button>
                                    <button 
                                      className="admin-btn reset" 
                                      onClick={() => alert('Функция недоступна в демо-режиме')}
                                    >
                                      Сбросить пароль
                                    </button>
                                    <button 
                                      className="admin-btn delete" 
                                      onClick={() => alert('Функция недоступна в демо-режиме')}
                                    >
                                      Удалить
                                    </button>
                                  </>
                                ) : (
                                  <span style={{color: '#666'}}>Текущий пользователь</span>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>
            )}

            {/* Security Section */}
            <section id="security" className="security">
              <h3 className="section-title">
                <span className="bracket">[</span>SECURITY<span className="bracket">]</span>
              </h3>
              <div className="security-content">
                <div className="security-item">
                  <h4>Anonymity</h4>
                  <p>All transactions are completely anonymous</p>
                  <p>AES-256 Encryption</p>
                </div>
                <div className="security-item">
                  <h4>Security</h4>
                  <p>Use Tor Browser only</p>
                  <p>No logs or tracking</p>
                </div>
              </div>
            </section>

            {/* Contact Section */}
            <section id="contact" className="contact">
              <h3 className="section-title">
                <span className="bracket">[</span>CONTACT<span className="bracket">]</span>
              </h3>
              <div className="contact-content">
                <div className="contact-item">
                  <h4>Support</h4>
                  <p>24/7 Technical Support</p>
                  <p>Telegram: <a href="https://t.me/tiktok_configs" target="_blank" className="telegram-link">@tiktok_configs</a></p>
                </div>
                <div className="contact-item">
                  <h4>Disclaimer</h4>
                  <p>For educational purposes only</p>
                  <p>Use at your own risk</p>
                </div>
              </div>
            </section>
          </div>
        </main>

        {/* Footer */}
        <footer className="footer">
          <div className="container">
            <div className="footer-content">
              <div className="footer-section">
                <h5>SECURITY</h5>
                <p>All transactions are anonymous</p>
                <p>AES-256 Encryption</p>
              </div>
              <div className="footer-section">
                <h5>SUPPORT</h5>
                <p>24/7 Technical Support</p>
                <p>Telegram: <a href="https://t.me/tiktok_configs" target="_blank" className="telegram-link">@tiktok_configs</a></p>
              </div>
              <div className="footer-section">
                <h5>DISCLAIMER</h5>
                <p>For educational purposes only</p>
                <p>Use at your own risk</p>
              </div>
            </div>
            <div className="footer-bottom">
              <p>&copy; 2024 TikTok Configs Shop. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>

      {/* Purchase Modal */}
      {showModal && selectedProduct && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <span className="modal-title">PAYMENT TERMINAL</span>
              <button className="modal-close" onClick={closeModal}>[X]</button>
            </div>
            <div className="modal-body">
              <div className="payment-info">
                <h4 id="modal-product-title">{selectedProduct.title}</h4>
                <div className="price-display">
                  <span className="price-label">PRICE:</span>
                  <span id="modal-price" className="price-value">{selectedProduct.price}</span>
                </div>
                <div className="btc-address">
                  <span className="address-label">BTC ADDRESS:</span>
                  <div className="address-container">
                    <code id="btc-address" className="btc-code">{selectedProduct.btcAddress}</code>
                    <button className="copy-btn" onClick={copyAddress}>COPY</button>
                  </div>
                </div>
                <div className="payment-instructions">
                  <p>1. Send the exact amount to the specified address</p>
                  <p>2. Wait for transaction confirmation</p>
                  <p>3. The file will be sent automatically</p>
                </div>
                <div className="security-notice">
                  <span className="warning-icon">⚠</span>
                  <span>Use Tor Browser only for maximum anonymity</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Fira+Code:wght@300;400;500&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Fira Code', monospace;
          background: #0a0a0a;
          color: #ffffff;
          overflow-x: hidden;
          line-height: 1.6;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
        }

        /* Matrix Background Effect */
        #matrix-bg {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
          background: #0a0a0a;
        }

        #matrix-canvas {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
          pointer-events: none;
          opacity: 1;
        }

        /* Header Styles */
        .header {
          padding: 20px 0;
          border-bottom: 1px solid #00ff41;
          background: rgba(10, 10, 10, 0.95);
          backdrop-filter: blur(10px);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .header .container {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .logo {
          font-family: 'Orbitron', sans-serif;
          font-size: 24px;
          font-weight: 700;
          color: #00ff41;
          text-shadow: 0 0 10px #00ff41;
          cursor: pointer;
        }

        .typing-text {
          animation: typing 3s steps(20) infinite;
        }

        .cursor {
          animation: blink 1s infinite;
        }

        @keyframes typing {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }

        @keyframes blink {
          0%, 50% { opacity: 1; }
          51%, 100% { opacity: 0; }
        }

        .nav {
          display: flex;
          gap: 30px;
        }

        .nav-link {
          color: #ffffff;
          text-decoration: none;
          font-weight: 500;
          transition: all 0.3s ease;
          position: relative;
          background: none;
          border: none;
          cursor: pointer;
          font-family: inherit;
        }

        .nav-link:hover {
          color: #00ff41;
          text-shadow: 0 0 5px #00ff41;
          border-color: #00ff41;
          box-shadow: 0 0 10px rgba(0, 255, 65, 0.3);
        }

        .nav-link::after {
          content: '';
          position: absolute;
          bottom: -5px;
          left: 0;
          width: 0;
          height: 1px;
          background: #00ff41;
          transition: width 0.3s ease;
        }

        .nav-link:hover::after {
          width: 100%;
        }

        /* Hero Section */
        .hero {
          padding: 80px 0;
          text-align: center;
        }

        .hero-title {
          font-family: 'Orbitron', sans-serif;
          font-size: 48px;
          font-weight: 900;
          margin-bottom: 20px;
        }

        .glitch {
          position: relative;
          color: #00ff41;
          text-shadow: 0 0 20px #00ff41;
          animation: glitch 2s infinite;
        }

        .glitch::before,
        .glitch::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        .glitch::before {
          animation: glitch-1 0.5s infinite;
          color: #ff0040;
          z-index: -1;
        }

        .glitch::after {
          animation: glitch-2 0.5s infinite;
          color: #00ffff;
          z-index: -2;
        }

        @keyframes glitch {
          0%, 100% { transform: translate(0); }
          20% { transform: translate(-2px, 2px); }
          40% { transform: translate(-2px, -2px); }
          60% { transform: translate(2px, 2px); }
          80% { transform: translate(2px, -2px); }
        }

        @keyframes glitch-1 {
          0%, 100% { transform: translate(0); }
          10% { transform: translate(-2px, -2px); }
          20% { transform: translate(2px, 2px); }
          30% { transform: translate(-2px, 2px); }
          40% { transform: translate(2px, -2px); }
        }

        @keyframes glitch-2 {
          0%, 100% { transform: translate(0); }
          10% { transform: translate(2px, 2px); }
          20% { transform: translate(-2px, -2px); }
          30% { transform: translate(2px, -2px); }
          40% { transform: translate(-2px, 2px); }
        }

        .hero-subtitle {
          font-size: 18px;
          color: #888888;
          margin-bottom: 40px;
        }

        /* Terminal Window */
        .terminal-window {
          background: #1a1a1a;
          border: 1px solid #00ff41;
          border-radius: 8px;
          margin: 40px auto;
          max-width: 600px;
          box-shadow: 0 0 20px rgba(0, 255, 65, 0.3);
        }

        .terminal-header {
          background: #2a2a2a;
          padding: 10px 15px;
          border-bottom: 1px solid #00ff41;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .terminal-button {
          width: 12px;
          height: 12px;
          border-radius: 50%;
        }

        .terminal-button.red { background: #ff5f56; }
        .terminal-button.yellow { background: #ffbd2e; }
        .terminal-button.green { background: #27ca3f; }

        .terminal-title {
          color: #00ff41;
          font-weight: 500;
          margin-left: auto;
        }

        .terminal-body {
          padding: 20px;
          font-family: 'Fira Code', monospace;
          font-size: 14px;
          line-height: 1.4;
        }

        .prompt {
          color: #00ff41;
          font-weight: bold;
        }

        /* Products Section */
        .products {
          padding: 80px 0;
        }

        .section-title {
          font-family: 'Orbitron', sans-serif;
          font-size: 36px;
          text-align: center;
          margin-bottom: 60px;
          color: #ffffff;
        }

        .bracket {
          color: #00ff41;
          text-shadow: 0 0 10px #00ff41;
        }

        .products-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 30px;
          margin-top: 40px;
        }

        /* Product Cards */
        .product-card {
          background: #1a1a1a;
          border: 1px solid #333333;
          border-radius: 12px;
          padding: 30px;
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        
        .product-card:hover {
          transform: translateY(-10px) scale(1.02);
          border-color: #00ff41;
          box-shadow: 0 0 30px rgba(0, 255, 65, 0.3);
        }

        .product-card.featured {
          border-color: #00ff41;
          box-shadow: 0 0 20px rgba(0, 255, 65, 0.2);
        }

        .product-card.ultimate {
          border-color: #f7931a;
          box-shadow: 0 0 20px rgba(247, 147, 26, 0.2);
        }
        
        .product-card.featured:hover {
          box-shadow: 0 0 30px rgba(0, 255, 65, 0.5);
        }

        .product-card.ultimate:hover {
          box-shadow: 0 0 30px rgba(247, 147, 26, 0.5);
        }

        .product-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .product-title {
          font-family: 'Orbitron', sans-serif;
          font-size: 20px;
          font-weight: 700;
          color: #ffffff;
        }

        .product-status {
          background: #333333;
          color: #ffffff;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 500;
        }

        .product-status.featured {
          background: #00ff41;
          color: #000000;
        }

        .product-status.ultimate {
          background: #f7931a;
          color: #000000;
        }

        .product-body {
          flex: 1;
        }

        .product-features {
          list-style: none;
          margin-bottom: 30px;
          padding: 0;
        }

        .product-features li {
          padding: 8px 0;
          color: #cccccc;
          font-size: 14px;
        }

        .product-features li::before {
          content: '>';
          color: #00ff41;
          font-weight: bold;
          margin-right: 8px;
        }

        .product-price {
          font-family: 'Orbitron', sans-serif;
          font-size: 28px;
          font-weight: 700;
          color: #f7931a;
          text-align: center;
          margin-bottom: 20px;
          text-shadow: 0 0 10px #f7931a;
        }

        /* Buy Button */
        .buy-btn {
          width: 100%;
          background: transparent;
          border: 2px solid #00ff41;
          color: #00ff41;
          padding: 15px 30px;
          font-family: 'Orbitron', sans-serif;
          font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          position: relative;
          overflow: hidden;
          transition: all 0.3s ease;
        }

        .buy-btn:hover {
          background: #00ff41;
          color: #000000;
          box-shadow: 0 0 20px #00ff41;
        }

        .btn-glow {
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
          transition: left 0.5s ease;
        }

        .buy-btn:hover .btn-glow {
          left: 100%;
        }

        /* Modal Styles */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.9);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 1000;
          backdrop-filter: blur(5px);
        }

        .modal {
          background: #1a1a1a;
          border: 2px solid #00ff41;
          border-radius: 12px;
          width: 90%;
          max-width: 500px;
          box-shadow: 0 0 50px rgba(0, 255, 65, 0.5);
          animation: modalAppear 0.3s ease;
        }

        @keyframes modalAppear {
          from {
            opacity: 0;
            transform: scale(0.8);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .modal-header {
          background: #2a2a2a;
          padding: 20px;
          border-bottom: 1px solid #00ff41;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .modal-title {
          font-family: 'Orbitron', sans-serif;
          font-size: 18px;
          font-weight: 700;
          color: #00ff41;
        }

        .modal-close {
          background: transparent;
          border: none;
          color: #ff0040;
          font-size: 18px;
          font-weight: bold;
          cursor: pointer;
          transition: color 0.3s ease;
        }

        .modal-close:hover {
          color: #ffffff;
        }

        .modal-body {
          padding: 30px;
        }

        .payment-info h4 {
          font-family: 'Orbitron', sans-serif;
          font-size: 20px;
          color: #ffffff;
          margin-bottom: 20px;
          text-align: center;
        }

        .price-display {
          text-align: center;
          margin-bottom: 30px;
        }

        .price-label {
          display: block;
          color: #888888;
          font-size: 14px;
          margin-bottom: 5px;
        }

        .price-value {
          font-family: 'Orbitron', sans-serif;
          font-size: 32px;
          font-weight: 700;
          color: #f7931a;
          text-shadow: 0 0 15px #f7931a;
        }

        .btc-address {
          margin-bottom: 30px;
        }

        .address-label {
          display: block;
          color: #888888;
          font-size: 14px;
          margin-bottom: 10px;
        }

        .address-container {
          display: flex;
          gap: 10px;
          align-items: center;
        }

        .btc-code {
          flex: 1;
          background: #0a0a0a;
          border: 1px solid #333333;
          padding: 12px;
          border-radius: 6px;
          color: #00ff41;
          font-family: 'Fira Code', monospace;
          font-size: 12px;
          word-break: break-all;
        }

        .copy-btn {
          background: #00ff41;
          border: none;
          color: #000000;
          padding: 12px 16px;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .copy-btn:hover {
          background: #ffffff;
          box-shadow: 0 0 10px #00ff41;
        }

        .payment-instructions {
          background: #0a0a0a;
          border: 1px solid #333333;
          border-radius: 6px;
          padding: 20px;
          margin-bottom: 20px;
        }

        .payment-instructions p {
          color: #cccccc;
          font-size: 14px;
          margin-bottom: 8px;
        }

        .security-notice {
          display: flex;
          align-items: center;
          gap: 10px;
          background: rgba(255, 0, 64, 0.1);
          border: 1px solid #ff0040;
          border-radius: 6px;
          padding: 15px;
          color: #ff0040;
          font-size: 14px;
        }

        .warning-icon {
          font-size: 18px;
        }

        /* Footer */
        .footer {
          background: #1a1a1a;
          border-top: 1px solid #333333;
          padding: 40px 0 20px;
          margin-top: 80px;
        }

        .footer-content {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 30px;
          margin-bottom: 30px;
        }

        .footer-section h5 {
          font-family: 'Orbitron', sans-serif;
          color: #00ff41;
          margin-bottom: 15px;
          font-size: 16px;
        }

        .footer-section p {
          color: #888888;
          font-size: 14px;
          margin-bottom: 5px;
        }

        .footer-bottom {
          text-align: center;
          padding-top: 20px;
          border-top: 1px solid #333333;
          color: #666666;
          font-size: 12px;
        }

        /* Admin Panel Styles */
        .admin-panel {
          margin-top: 50px;
          padding: 30px;
          background: rgba(0, 255, 65, 0.05);
          border: 1px solid rgba(0, 255, 65, 0.2);
          border-radius: 10px;
          width: 100%;
          max-width: 1800px;
          margin-left: auto;
          margin-right: auto;
        }

        .users-table-container {
          overflow-x: auto;
          margin-top: 20px;
          width: 100%;
          padding: 0 30px;
        }

        .users-table {
          width: 100%;
          min-width: 1400px;
          border-collapse: collapse;
          background: rgba(0, 0, 0, 0.3);
          border-radius: 8px;
          overflow: hidden;
          table-layout: fixed;
        }

        .users-table th,
        .users-table td {
          padding: 8px 12px;
          text-align: left;
          border-bottom: 1px solid rgba(0, 255, 65, 0.2);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .users-table th:nth-child(1), .users-table td:nth-child(1) { width: 40px; }
        .users-table th:nth-child(2), .users-table td:nth-child(2) { width: 80px; }
        .users-table th:nth-child(3), .users-table td:nth-child(3) { width: 120px; }
        .users-table th:nth-child(4), .users-table td:nth-child(4) { width: 100px; }
        .users-table th:nth-child(5), .users-table td:nth-child(5) { width: 80px; }
        .users-table th:nth-child(6), .users-table td:nth-child(6) { width: 100px; }
        .users-table th:nth-child(7), .users-table td:nth-child(7) { width: 120px; }
        .users-table th:nth-child(8), .users-table td:nth-child(8) { width: 80px; }
        .users-table th:nth-child(9), .users-table td:nth-child(9) { width: 80px; }
        .users-table th:nth-child(10), .users-table td:nth-child(10) { width: 120px; }
        .users-table th:nth-child(11), .users-table td:nth-child(11) { width: 200px; }

        .users-table th {
          background: rgba(0, 255, 65, 0.1);
          color: #00ff41;
          font-weight: 700;
          text-transform: uppercase;
          font-size: 0.8rem;
          letter-spacing: 1px;
        }

        .users-table td {
          color: #ffffff;
          font-size: 0.9rem;
        }

        .users-table tr:hover {
          background: rgba(0, 255, 65, 0.05);
        }

        .status-badge {
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 0.7rem;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .status-badge.active {
          background: rgba(46, 204, 113, 0.2);
          color: #2ecc71;
          border: 1px solid rgba(46, 204, 113, 0.5);
        }

        .status-badge.inactive {
          background: rgba(231, 76, 60, 0.2);
          color: #e74c3c;
          border: 1px solid rgba(231, 76, 60, 0.5);
        }

        .admin-badge {
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 0.7rem;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          background: rgba(255, 193, 7, 0.2);
          color: #ffc107;
          border: 1px solid rgba(255, 193, 7, 0.5);
        }

        .admin-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .admin-btn {
          padding: 6px 12px;
          border: none;
          border-radius: 4px;
          font-size: 0.7rem;
          font-weight: 600;
          text-transform: uppercase;
          cursor: pointer;
          transition: all 0.3s ease;
          font-family: 'Fira Code', monospace;
        }

        .admin-btn.toggle {
          background: rgba(52, 152, 219, 0.2);
          color: #3498db;
          border: 1px solid rgba(52, 152, 219, 0.5);
        }

        .admin-btn.toggle:hover {
          background: rgba(52, 152, 219, 0.3);
          color: #ffffff;
        }

        .admin-btn.reset {
          background: rgba(255, 193, 7, 0.2);
          color: #ffc107;
          border: 1px solid rgba(255, 193, 7, 0.5);
        }

        .admin-btn.reset:hover {
          background: rgba(255, 193, 7, 0.3);
          color: #ffffff;
        }

        .admin-btn.delete {
          background: rgba(231, 76, 60, 0.2);
          color: #e74c3c;
          border: 1px solid rgba(231, 76, 60, 0.5);
        }

        .admin-btn.delete:hover {
          background: rgba(231, 76, 60, 0.3);
          color: #ffffff;
        }

        /* Security and Contact Sections */
        .security, .contact {
          padding: 60px 0;
        }

        .security-content, .contact-content {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 30px;
        }

        .security-item, .contact-item {
          background: rgba(0, 255, 65, 0.05);
          border: 1px solid rgba(0, 255, 65, 0.2);
          border-radius: 10px;
          padding: 20px;
        }

        .security-item h4, .contact-item h4 {
          font-family: 'Orbitron', sans-serif;
          color: #00ff41;
          margin-bottom: 15px;
          font-size: 18px;
        }

        .security-item p, .contact-item p {
          color: #cccccc;
          font-size: 14px;
          margin-bottom: 8px;
        }

        /* Telegram link styles */
        .telegram-link {
          color: #00ff41;
          text-decoration: none;
          transition: all 0.3s ease;
          border-bottom: 1px solid transparent;
        }

        .telegram-link:hover {
          color: #ffffff;
          text-shadow: 0 0 10px #00ff41;
          border-bottom: 1px solid #00ff41;
        }

        .telegram-link:active {
          color: #00cc33;
        }

        /* Dropdown menu styles */
        .nav-item.dropdown {
          position: relative;
          display: inline-block;
        }

        .dropdown-toggle {
          cursor: pointer;
        }

        .dropdown-menu {
          position: absolute;
          top: 100%;
          left: 0;
          background: rgba(0, 0, 0, 0.95);
          border: 1px solid #00ff41;
          border-radius: 4px;
          min-width: 120px;
          opacity: 0;
          visibility: hidden;
          transform: translateY(-10px);
          transition: all 0.3s ease;
          z-index: 1000;
          box-shadow: 0 4px 15px rgba(0, 255, 65, 0.3);
          display: none;
        }

        .dropdown-menu.show {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
          display: block;
        }

        .dropdown-item {
          display: block;
          padding: 8px 12px;
          color: #00ff41;
          text-decoration: none;
          font-family: 'Courier New', monospace;
          font-size: 12px;
          border-bottom: 1px solid rgba(0, 255, 65, 0.2);
          transition: all 0.3s ease;
          white-space: nowrap;
        }

        .dropdown-item:last-child {
          border-bottom: none;
        }

        .dropdown-item:hover {
          background: rgba(0, 255, 65, 0.1);
          color: #ffffff;
          text-shadow: 0 0 10px #00ff41;
          padding-left: 16px;
        }

        .dropdown-toggle::after {
          content: ' ▼';
          font-size: 8px;
          transition: transform 0.3s ease;
        }

        .dropdown.active .dropdown-toggle::after {
          transform: rotate(180deg);
        }

        /* Download Button Styles */
        .download-btn {
          color: #f7931a !important;
          border-color: #f7931a !important;
        }

        .download-btn:hover {
          color: #ffffff !important;
          text-shadow: 0 0 5px #f7931a !important;
          border-color: #f7931a !important;
          box-shadow: 0 0 10px rgba(247, 147, 26, 0.3) !important;
        }

        .download-btn::after {
          content: '';
          position: absolute;
          bottom: -5px;
          left: 0;
          width: 0;
          height: 1px;
          background: #f7931a;
          transition: width 0.3s ease;
        }

        .download-btn:hover::after {
          width: 100%;
        }

        /* Scrollbar Styling */
        ::-webkit-scrollbar {
          width: 8px;
        }

        ::-webkit-scrollbar-track {
          background: #1a1a1a;
        }

        ::-webkit-scrollbar-thumb {
          background: #00ff41;
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: #ffffff;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .hero-title {
            font-size: 32px;
          }
          
          .section-title {
            font-size: 28px;
          }
          
          .products-grid {
            grid-template-columns: 1fr;
            padding: 0 15px;
          }
          
          .nav {
            flex-direction: column;
            gap: 15px;
          }
          
          .header .container {
            flex-direction: column;
            gap: 20px;
          }
          
          .terminal-body {
            font-size: 12px;
          }
          
          .address-container {
            flex-direction: column;
          }
          
          .btc-code {
            font-size: 10px;
          }

          .auth-container {
            padding: 30px 20px;
            width: 350px;
          }
          
          .auth-title {
            font-size: 2rem;
          }
          
          .users-table {
            font-size: 0.8rem;
          }
          
          .users-table th,
          .users-table td {
            padding: 8px 10px;
          }
          
          .admin-actions {
            flex-direction: column;
          }
          
          .admin-btn {
            width: 100%;
            margin-bottom: 4px;
          }
        }

        @media (max-width: 480px) {
          .hero-title {
            font-size: 28px;
          }

          .hero-subtitle {
            font-size: 16px;
          }

          .section-title {
            font-size: 24px;
          }

          .terminal-body {
            font-size: 10px;
            padding: 15px;
          }

          .product-card {
            padding: 20px;
          }

          .product-title {
            font-size: 18px;
          }

          .product-price {
            font-size: 24px;
          }

          .buy-btn {
            font-size: 14px;
            padding: 12px 20px;
          }

          .modal {
            width: 95%;
          }

          .modal-body {
            padding: 20px;
          }

          .payment-info h4 {
            font-size: 18px;
          }

          .price-value {
            font-size: 28px;
          }

          .btc-code {
            font-size: 10px;
          }

          .copy-btn {
            padding: 10px 14px;
          }

          .payment-instructions p {
            font-size: 12px;
          }

          .security-notice {
            font-size: 12px;
            padding: 10px;
          }

          .footer-content {
            grid-template-columns: 1fr;
          }

          .auth-container {
            padding: 30px;
          }

          .auth-title {
            font-size: 2rem;
          }

          .auth-tab {
            padding: 10px 15px;
            font-size: 0.8rem;
          }

          .form-group input {
            padding: 12px;
            font-size: 0.8rem;
          }

          .auth-btn {
            font-size: 0.9rem;
          }

          .admin-panel {
            padding: 20px 0;
          }

          .users-table-container {
            padding: 0 10px;
          }

          .users-table th,
          .users-table td {
            padding: 6px 8px;
            font-size: 0.8rem;
          }

          .admin-actions {
            flex-direction: column;
            gap: 5px;
          }

          .admin-btn {
            padding: 5px 10px;
            font-size: 0.7rem;
          }
        }

        @media (max-width: 320px) {
          .hero-title {
            font-size: 24px;
          }

          .section-title {
            font-size: 20px;
          }

          .product-title {
            font-size: 16px;
          }

          .product-price {
            font-size: 20px;
          }

          .auth-title {
            font-size: 1.8rem;
          }

          .auth-tab {
            font-size: 0.7rem;
          }

          .form-group input {
            font-size: 0.7rem;
          }

          .auth-btn {
            font-size: 0.8rem;
          }
        }
      `}</style>
    </>
  );
}