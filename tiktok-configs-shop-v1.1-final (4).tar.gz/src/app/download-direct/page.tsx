export default function DownloadDirectPage() {
  return (
    <div className="min-h-screen bg-black text-green-400 p-8">
      <div className="max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-8">Скачать TikTok_Configs.shop</h1>
        
        <div className="bg-gray-900 border-green-600 rounded-lg p-8 mb-8">
          <h2 className="text-2xl mb-4">Прямая ссылка на скачивание</h2>
          <p className="mb-6">Нажмите на ссылку ниже, чтобы скачать архив проекта:</p>
          
          <a 
            href="/tiktok-configs-shop.tar.gz" 
            className="inline-block bg-green-600 hover:bg-green-700 text-black font-bold px-8 py-4 rounded-lg transition-colors"
            download="tiktok-configs-shop.tar.gz"
          >
            📥 Скачать архив (161 KB)
          </a>
        </div>

        <div className="bg-gray-900 border-green-600 rounded-lg p-6 text-left">
          <h3 className="text-xl mb-4">Инструкция по развертыванию:</h3>
          <div className="space-y-3 font-mono text-sm">
            <div>1. Распакуйте архив:</div>
            <code className="block bg-black p-2 rounded text-green-400 mb-3">
              tar -xzf tiktok-configs-shop.tar.gz<br/>
              cd tiktok-configs-shop
            </code>
            
            <div>2. Установите зависимости:</div>
            <code className="block bg-black p-2 rounded text-green-400 mb-3">
              npm install
            </code>
            
            <div>3. Запустите проект:</div>
            <code className="block bg-black p-2 rounded text-green-400">
              npm run dev
            </code>
          </div>
          
          <div className="mt-6 p-4 bg-yellow-900/30 border border-yellow-600 rounded">
            <p className="text-yellow-400 text-sm">
              <strong>Важно:</strong> После запуска проект будет доступен по адресу http://localhost:3000
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}