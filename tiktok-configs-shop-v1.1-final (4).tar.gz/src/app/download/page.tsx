'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Download, FileArchive, CheckCircle } from 'lucide-react'

export default function DownloadPage() {
  const [isDownloading, setIsDownloading] = useState(false)
  const [downloadComplete, setDownloadComplete] = useState(false)

  const handleDownload = async () => {
    setIsDownloading(true)
    
    try {
      // Create a download link for the archive
      const response = await fetch('/api/download-archive', {
        method: 'GET',
      })
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'tiktok-configs-shop.tar.gz'
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        
        setDownloadComplete(true)
      } else {
        alert('Ошибка при скачивании архива')
      }
    } catch (error) {
      console.error('Download error:', error)
      alert('Ошибка при скачивании архива')
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black text-green-400 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">Скачать TikTok_Configs.shop</h1>
          <p className="text-lg opacity-80">Полный архив проекта для самостоятельного развертывания</p>
        </div>

        <Card className="bg-gray-900 border-green-600 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileArchive className="h-6 w-6" />
              Информация об архиве
            </CardTitle>
            <CardDescription className="text-green-400">
              Полный проект готов к скачиванию и развертыванию
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Размер файла:</span>
                  <span className="font-mono">~161 KB</span>
                </div>
                <div className="flex justify-between">
                  <span>Формат:</span>
                  <span className="font-mono">.tar.gz</span>
                </div>
                <div className="flex justify-between">
                  <span>Версия:</span>
                  <span className="font-mono">1.0.0</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Технологии:</span>
                  <span className="font-mono text-xs">Next.js, TypeScript</span>
                </div>
                <div className="flex justify-between">
                  <span>База данных:</span>
                  <span className="font-mono">SQLite</span>
                </div>
                <div className="flex justify-between">
                  <span>Стили:</span>
                  <span className="font-mono">Tailwind CSS</span>
                </div>
              </div>
            </div>

            <div className="text-center">
              {downloadComplete ? (
                <div className="flex items-center justify-center gap-2 text-green-400">
                  <CheckCircle className="h-5 w-5" />
                  <span>Архив успешно скачан!</span>
                </div>
              ) : (
                <Button 
                  onClick={handleDownload}
                  disabled={isDownloading}
                  className="bg-green-600 hover:bg-green-700 text-black font-bold px-8 py-3"
                >
                  {isDownloading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black mr-2"></div>
                      Скачивание...
                    </>
                  ) : (
                    <>
                      <Download className="h-5 w-5 mr-2" />
                      Скачать архив
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-green-600">
          <CardHeader>
            <CardTitle>Инструкция по развертыванию</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-sm">
              <div className="bg-gray-800 p-4 rounded">
                <h3 className="font-bold mb-2">1. Распакуйте архив</h3>
                <code className="block bg-black p-2 rounded text-green-400">
                  tar -xzf tiktok-configs-shop.tar.gz<br/>
                  cd tiktok-configs-shop
                </code>
              </div>
              
              <div className="bg-gray-800 p-4 rounded">
                <h3 className="font-bold mb-2">2. Установите зависимости</h3>
                <code className="block bg-black p-2 rounded text-green-400">
                  npm install
                </code>
              </div>
              
              <div className="bg-gray-800 p-4 rounded">
                <h3 className="font-bold mb-2">3. Запустите проект</h3>
                <code className="block bg-black p-2 rounded text-green-400">
                  npm run dev
                </code>
              </div>
              
              <div className="bg-gray-800 p-4 rounded">
                <h3 className="font-bold mb-2">4. Откройте в браузере</h3>
                <code className="block bg-black p-2 rounded text-green-400">
                  http://localhost:3000
                </code>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}