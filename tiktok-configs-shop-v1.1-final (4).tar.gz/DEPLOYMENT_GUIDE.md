# TikTok_Configs.shop - Deployment Guide

## Project Overview
This is a complete Next.js + TypeScript + Tailwind CSS implementation of the TikTok_Configs.shop website with Matrix rain effects, authentication system, and product management.

## Prerequisites
- Node.js 18+ 
- npm or yarn
- SQLite (included)

## Installation Steps

### 1. Extract the Archive
```bash
tar -xzf tiktok-configs-shop.tar.gz
cd tiktok-configs-shop
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Database Setup
The project uses SQLite with Prisma. The database file is already included in the `db/` directory.

### 4. Start Development Server
```bash
npm run dev
```

### 5. Build for Production
```bash
npm run build
npm start
```

## Test Accounts
- **Administrator**: `admin` / `admin123`
- **Regular User**: `testuser` / `testpass123`

## Features
- ✅ Matrix rain background effect
- ✅ User authentication (login/register)
- ✅ Product showcase (15 products across 3 categories)
- ✅ BTC payment system
- ✅ Admin panel for user management
- ✅ Responsive design
- ✅ Real-time updates with Socket.IO

## Project Structure
```
src/
├── app/                 # Next.js app router
├── components/          # React components
├── hooks/              # Custom hooks
└── lib/                # Utilities and configurations
```

## Environment Variables
No additional environment variables required for basic functionality.

## Support
For any issues or questions, refer to the original project documentation or contact support.

---

**Note**: The archive includes all necessary files, dependencies, and the pre-configured database. Simply extract and run to get started!